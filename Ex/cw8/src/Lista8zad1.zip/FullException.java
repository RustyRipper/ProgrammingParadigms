//Maciej Makara
//zadanie 1
public class FullException extends Exception {
    public FullException() {
    }
    public FullException(String msg) {
        super(msg);
    }
}
