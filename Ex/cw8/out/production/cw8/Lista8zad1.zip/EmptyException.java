//Maciej Makara
//zadanie 1
public class EmptyException extends Exception {
    public EmptyException() {
    }
    public EmptyException(String msg) {
        super(msg);
    }
}
